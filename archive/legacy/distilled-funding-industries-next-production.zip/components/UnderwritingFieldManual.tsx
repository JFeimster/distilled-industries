import type { IndustryPage } from "@/lib/types";
import { SectionHeading } from "@/components/SectionHeading";

export function UnderwritingFieldManual({
  snapshot,
}: {
  snapshot: IndustryPage["qualificationSnapshot"];
}) {
  return (
    <section className="section sectionAlt">
      <div className="shell">
        <SectionHeading
          eyebrow="UNDERWRITING FIELD MANUAL"
          title={snapshot.title}
          copy="Bring the facts that help kill bad-fit lanes early and protect the good ones."
        />
        <div className="manualGrid">
          <div className="manualPanel">
            <div className="terminalLabel">SIGNALS_TO_CHECK</div>
            <ul>
              {snapshot.signals.map((signal) => (
                <li key={signal}>{signal}</li>
              ))}
            </ul>
          </div>
          <div className="manualPanel">
            <div className="terminalLabel">DOCUMENTS_TO_BRING</div>
            <ul>
              {snapshot.commonDocuments.map((document) => (
                <li key={document.documentKey}>{document.label}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
