import Link from "next/link";
import type { IndustryLink } from "@/lib/types";
import { SectionHeading } from "@/components/SectionHeading";

export function RelatedIndustries({ items }: { items: IndustryLink[] }) {
  return (
    <section className="section sectionAlt">
      <div className="shell">
        <SectionHeading
          eyebrow="ADJACENT ROUTES"
          title="RELATED INDUSTRIES."
          copy="Similar operating models, cash cycles, and capital-use patterns."
        />
        <div className="relatedRail">
          {items.map((item) => (
            <Link href={item.route} key={item.route}>
              {item.label} <b>→</b>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
