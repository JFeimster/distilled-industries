import { Breadcrumbs } from "@/components/Breadcrumbs";
import { IndustryHero } from "@/components/IndustryHero";
import { CategoryIndustryGrid } from "@/components/CategoryIndustryGrid";
import { FundingLanes } from "@/components/FundingLanes";
import { ConversionRail } from "@/components/ConversionRail";
import { SectionHeading } from "@/components/SectionHeading";
import { JsonLd } from "@/components/JsonLd";
import { categorySchema } from "@/lib/schema";
import type { CategoryPage } from "@/lib/types";

export function CategoryPageView({ page }: { page: CategoryPage }) {
  return (
    <main>
      <JsonLd data={categorySchema(page)} />
      <Breadcrumbs
        items={[
          { label: "Industries", href: "/" },
          { label: page.label },
        ]}
      />
      <IndustryHero
        eyebrow={page.hero.eyebrow}
        headline={page.hero.headline}
        subheadline={page.hero.subheadline}
        primaryCta={page.hero.primaryCta}
      />

      <section className="section">
        <div className="shell">
          <SectionHeading
            eyebrow={`${String(page.industryCount).padStart(2, "0")} GUIDES`}
            title="PICK THE BUSINESS MODEL."
            copy="Each child route is a production page contract—not a generic clone with the industry name swapped."
          />
          <CategoryIndustryGrid industries={page.industries} />
        </div>
      </section>

      <FundingLanes paths={page.fundingPaths} categoryMode />

      <ConversionRail
        headline="FUND THE OPERATING REALITY."
        disclaimer={page.compliance.disclaimer}
        href={page.hero.primaryCta.href}
      />
    </main>
  );
}
