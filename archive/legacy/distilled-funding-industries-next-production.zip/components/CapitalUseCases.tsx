import type { IndustryPage } from "@/lib/types";
import { SectionHeading } from "@/components/SectionHeading";

export function CapitalUseCases({
  items,
}: {
  items: IndustryPage["capitalUseCases"];
}) {
  return (
    <section className="section sectionAlt">
      <div className="shell">
        <SectionHeading
          eyebrow="USE OF FUNDS"
          title="WHERE CAPITAL ACTUALLY GOES."
          copy="The operating need comes first. The capital structure follows."
        />
        <div className="fourGrid">
          {items.map((item) => (
            <article className="brutalCard" key={item.number}>
              <div className="cardIndex">{item.number}</div>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
              <code>{item.fundingFamily}</code>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
