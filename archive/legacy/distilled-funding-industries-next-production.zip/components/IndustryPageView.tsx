import { Breadcrumbs } from "@/components/Breadcrumbs";
import { IndustryHero } from "@/components/IndustryHero";
import { MoneyGap } from "@/components/MoneyGap";
import { CapitalUseCases } from "@/components/CapitalUseCases";
import { FundingLanes } from "@/components/FundingLanes";
import { UnderwritingFieldManual } from "@/components/UnderwritingFieldManual";
import { IndustryFAQ } from "@/components/IndustryFAQ";
import { RelatedIndustries } from "@/components/RelatedIndustries";
import { ConversionRail } from "@/components/ConversionRail";
import { JsonLd } from "@/components/JsonLd";
import { OperatorStatusRail } from "@/components/OperatorStatusRail";
import { industrySchema } from "@/lib/schema";
import type { IndustryPage } from "@/lib/types";

export function IndustryPageView({ page }: { page: IndustryPage }) {
  return (
    <main>
      <JsonLd data={industrySchema(page)} />
      <Breadcrumbs
        items={[
          { label: "Industries", href: "/" },
          { label: page.categoryLabel, href: `/${page.categorySlug}` },
          { label: page.label },
        ]}
      />
      <OperatorStatusRail category={page.categoryLabel} label={page.label} route={page.route} />
      <IndustryHero
        eyebrow={page.hero.eyebrow}
        headline={page.hero.headline}
        subheadline={page.hero.subheadline}
        primaryCta={page.hero.primaryCta}
        secondaryCta={page.hero.secondaryCta}
      />
      <MoneyGap operatingReality={page.operatingReality} />
      <CapitalUseCases items={page.capitalUseCases} />
      <FundingLanes paths={page.recommendedFundingPaths} />
      <UnderwritingFieldManual snapshot={page.qualificationSnapshot} />
      <IndustryFAQ faq={page.faq} />
      <RelatedIndustries items={page.relatedIndustries} />
      <ConversionRail
        disclaimer={page.compliance.disclaimer}
        href={page.hero.primaryCta.href}
      />
    </main>
  );
}
