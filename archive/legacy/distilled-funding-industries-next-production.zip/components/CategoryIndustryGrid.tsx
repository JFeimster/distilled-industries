import Link from "next/link";
import type { CategoryPage } from "@/lib/types";

export function CategoryIndustryGrid({
  industries,
}: {
  industries: CategoryPage["industries"];
}) {
  return (
    <div className="categoryGrid">
      {industries.map((industry, index) => (
        <Link
          className="brutalCard categoryCard"
          href={industry.route}
          key={industry.route}
        >
          <div className="cardIndex">{String(index + 1).padStart(2, "0")}</div>
          <div>
            <h3>{industry.label}</h3>
            <p>{industry.hook}</p>
          </div>
          <strong>OPEN GUIDE →</strong>
        </Link>
      ))}
    </div>
  );
}
