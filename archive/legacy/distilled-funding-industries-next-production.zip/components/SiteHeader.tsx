import Link from "next/link";
import { navigationManifest } from "@/lib/navigation";

export function SiteHeader() {
  return (
    <header className="siteHeader">
      <div className="shell headerInner">
        <Link href="/" className="brandMark">
          <span>DISTILLED</span> <b>FUNDING</b> <i>// INDUSTRIES</i>
        </Link>

        <nav className="desktopNav" aria-label="Primary navigation">
          <details className="megaNav">
            <summary>Industries <span>▾</span></summary>
            <div className="megaPanel">
              <div className="megaPanelHeader">
                <div>
                  <small>15 CAPITAL SECTORS</small>
                  <strong>CHOOSE THE OPERATING MODEL.</strong>
                </div>
                <Link href="/">VIEW ALL 100 →</Link>
              </div>
              <div className="megaColumns">
                {navigationManifest.primary.map((item, index) => (
                  <div className="megaGroup" key={item.href}>
                    <div className="megaIndex">{String(index + 1).padStart(2, "0")}</div>
                    <Link className="megaGroupTitle" href={item.href}>
                      {item.label}
                    </Link>
                    <div className="megaChildren">
                      {(item.children ?? []).slice(0, 4).map((child) => (
                        <Link href={child.href} key={child.href}>
                          {child.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </details>

          <a href={navigationManifest.brand.mainSite}>Main Site</a>
          <a
            className="button buttonGold compactButton"
            href="https://www.distilledfunding.com/apply"
          >
            Check Funding Options
          </a>
        </nav>
      </div>
    </header>
  );
}
