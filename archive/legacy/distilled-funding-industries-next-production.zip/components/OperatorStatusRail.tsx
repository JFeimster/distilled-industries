export function OperatorStatusRail({
  category,
  label,
  route,
}: {
  category: string;
  label: string;
  route: string;
}) {
  return (
    <section className="operatorStatus" aria-label="Page routing status">
      <div className="shell operatorStatusInner">
        <span>STATUS <b>LIVE</b></span>
        <span>SECTOR <b>{category}</b></span>
        <span>INDUSTRY <b>{label}</b></span>
        <span>ROUTE <code>{route}</code></span>
      </div>
    </section>
  );
}
