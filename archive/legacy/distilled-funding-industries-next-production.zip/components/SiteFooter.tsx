export function SiteFooter() {
  return (
    <footer className="siteFooter">
      <div className="shell footerGrid">
        <div>
          <strong>DISTILLED FUNDING // INDUSTRIES</strong>
          <p>Industry-specific capital intelligence built around operating reality.</p>
        </div>
        <div className="footerMeta">
          <a href="https://www.distilledfunding.com/">Main Site</a>
          <a href="https://www.distilledfunding.com/apply">Apply</a>
        </div>
      </div>
    </footer>
  );
}
