export function StatStrip({
  stats,
}: {
  stats: Array<{ value: string; label: string }>;
}) {
  return (
    <section className="statStrip" aria-label="Industry directory statistics">
      {stats.map((stat) => (
        <div className="statCell" key={stat.label}>
          <strong>{stat.value}</strong>
          <span>{stat.label}</span>
        </div>
      ))}
    </section>
  );
}
