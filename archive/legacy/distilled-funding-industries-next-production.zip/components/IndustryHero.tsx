import type { Cta } from "@/lib/types";

export function IndustryHero({
  eyebrow,
  headline,
  subheadline,
  primaryCta,
  secondaryCta,
}: {
  eyebrow: string;
  headline: string;
  subheadline: string;
  primaryCta: Cta;
  secondaryCta?: Cta;
}) {
  return (
    <section className="heroSection">
      <div className="shell">
        <div className="eyebrow">{eyebrow}</div>
        <h1>{headline}</h1>
        <p className="heroCopy">{subheadline}</p>
        <div className="heroActions">
          <a className="button buttonGold" href={primaryCta.href}>
            {primaryCta.label}
          </a>
          {secondaryCta && (
            <a className="button" href={secondaryCta.href}>
              {secondaryCta.label}
            </a>
          )}
        </div>
      </div>
    </section>
  );
}
