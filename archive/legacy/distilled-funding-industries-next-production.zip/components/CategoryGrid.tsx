import Link from "next/link";
import type { HomepageContract } from "@/lib/types";

export function CategoryGrid({
  categories,
}: {
  categories: HomepageContract["categories"];
}) {
  return (
    <div className="categoryGrid">
      {categories.map((category, index) => (
        <Link
          href={category.route}
          className="brutalCard categoryCard"
          key={category.id}
        >
          <div className="cardIndex">{String(index + 1).padStart(2, "0")}</div>
          <div>
            <div className="cardMeta">
              {String(category.industryCount).padStart(2, "0")} GUIDES
            </div>
            <h3>{category.label}</h3>
            <p>{category.hook}</p>
          </div>
          <strong>OPEN SECTOR →</strong>
        </Link>
      ))}
    </div>
  );
}
