import type { IndustryPage } from "@/lib/types";
import { SectionHeading } from "@/components/SectionHeading";

export function IndustryFAQ({ faq }: { faq: IndustryPage["faq"] }) {
  return (
    <section className="section">
      <div className="shell">
        <SectionHeading
          eyebrow="FAST QUESTIONS"
          title="SKIP THE FANTASY UNDERWRITING."
          copy="Practical answers built around qualification, documentation, and fit."
        />
        <div className="faqList">
          {faq.map((item) => (
            <details key={item.question}>
              <summary>{item.question}</summary>
              <p>{item.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
