import { IndustryHero } from "@/components/IndustryHero";
import { StatStrip } from "@/components/StatStrip";
import { SectionHeading } from "@/components/SectionHeading";
import { CategoryGrid } from "@/components/CategoryGrid";
import { IndustrySearch } from "@/components/IndustrySearch";
import { ConversionRail } from "@/components/ConversionRail";
import { JsonLd } from "@/components/JsonLd";
import { homepageSchema } from "@/lib/schema";
import { getIndustrySearchIndex } from "@/lib/industries";
import type { HomepageContract } from "@/lib/types";

export function HomepageView({ page }: { page: HomepageContract }) {
  return (
    <main>
      <JsonLd data={homepageSchema(page)} />
      <IndustryHero
        eyebrow={page.hero.eyebrow}
        headline={page.hero.headline}
        subheadline={page.hero.subheadline}
        primaryCta={page.hero.primaryCta}
      />
      <StatStrip stats={page.stats} />

      <section className="section">
        <div className="shell">
          <SectionHeading
            eyebrow="SECTOR MAP"
            title="CHOOSE THE OPERATING MODEL."
            copy="Start with the sector. Drill down to the business model. Match capital to the real cash cycle."
          />
          <CategoryGrid categories={page.categories} />
        </div>
      </section>

      <section className="section sectionAlt">
        <div className="shell">
          <SectionHeading
            eyebrow="100 INDUSTRY GUIDES"
            title="SEARCH THE WHOLE DAMN MAP."
            copy="Every route is generated from the canonical manifest, with its own operating reality, funding uses, qualification signals, and internal links."
          />
          <IndustrySearch
            items={getIndustrySearchIndex()}
            placeholder={page.hero.searchPlaceholder}
          />
        </div>
      </section>

      <ConversionRail
        headline="YOU DON'T NEED MORE APPLICATIONS. YOU NEED THE RIGHT LANE."
        disclaimer={page.compliance.disclaimer}
        href={page.primaryApplicationUrl}
      />
    </main>
  );
}
