import type { IndustryPage } from "@/lib/types";
import { SectionHeading } from "@/components/SectionHeading";

export function MoneyGap({
  operatingReality,
}: {
  operatingReality: IndustryPage["operatingReality"];
}) {
  return (
    <section className="section">
      <div className="shell">
        <SectionHeading
          eyebrow="OPERATING REALITY"
          title={operatingReality.title}
          copy={operatingReality.summary}
        />
        <div className="threeGrid">
          {operatingReality.painPoints.map((point) => (
            <article className="brutalCard offsetGold" key={point.number}>
              <div className="cardIndex">{point.number}</div>
              <h3>{point.title}</h3>
              <p>{point.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
