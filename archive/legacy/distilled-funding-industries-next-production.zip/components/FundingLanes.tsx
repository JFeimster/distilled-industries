import type { FundingPath } from "@/lib/types";
import { SectionHeading } from "@/components/SectionHeading";

export function FundingLanes({
  paths,
  categoryMode = false,
}: {
  paths: FundingPath[];
  categoryMode?: boolean;
}) {
  return (
    <section className="section">
      <div className="shell">
        <SectionHeading
          eyebrow="CAPITAL ROUTING"
          title={categoryMode ? "THE CAPITAL LANES." : "PRIORITIZE THE LANE. THEN UNDERWRITE."}
          copy="These are ranked starting points. The actual file determines the final fit."
        />
        <div className="laneGrid">
          {paths.map((path, index) => (
            <article className="lanePanel" key={path.familySlug}>
              <div className="laneTop">
                <span>LANE_{String(index + 1).padStart(2, "0")}</span>
                <b>{path.familySlug}</b>
              </div>
              <h3>{path.label}</h3>
              <p>{path.rationale}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
