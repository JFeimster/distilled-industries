export function ConversionRail({
  headline = "UNDERSTAND THE FILE. THEN CHOOSE THE CAPITAL.",
  disclaimer,
  href = "https://www.distilledfunding.com/apply",
}: {
  headline?: string;
  disclaimer: string;
  href?: string;
}) {
  return (
    <section className="conversionRail">
      <div className="shell">
        <div className="eyebrow darkEyebrow">THE NEXT MOVE</div>
        <h2>{headline}</h2>
        <p>{disclaimer}</p>
        <a className="button conversionButton" href={href}>
          CHECK FUNDING OPTIONS
        </a>
      </div>
    </section>
  );
}
