const phrase =
  "UNDERSTAND THE FILE • MATCH THE CAPITAL LANE • KILL BAD FIT EARLY • DOCUMENT THE STORY • FUND THE REAL CASH CYCLE • ";

export function TickerRail() {
  return (
    <div className="tickerRail" aria-hidden="true">
      <div>{phrase.repeat(5)}</div>
    </div>
  );
}
