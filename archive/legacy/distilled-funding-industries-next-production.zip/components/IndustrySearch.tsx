"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

type SearchItem = {
  slug: string;
  route: string;
  label: string;
  categoryLabel: string;
  categorySlug: string;
  keywords: string;
};

export function IndustrySearch({
  items,
  placeholder,
}: {
  items: SearchItem[];
  placeholder: string;
}) {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter((item) =>
      `${item.label} ${item.categoryLabel} ${item.keywords}`
        .toLowerCase()
        .includes(q)
    );
  }, [items, query]);

  return (
    <div>
      <div className="searchControl">
        <span>SEARCH_100:</span>
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={placeholder}
          aria-label="Search industries"
        />
        <b>{results.length} MATCHES</b>
      </div>
      <div className="industryIndex">
        {results.map((item) => (
          <Link className="industryRow" href={item.route} key={item.route}>
            <span>{item.label}</span>
            <small>{item.categoryLabel}</small>
            <b>→</b>
          </Link>
        ))}
      </div>
    </div>
  );
}
