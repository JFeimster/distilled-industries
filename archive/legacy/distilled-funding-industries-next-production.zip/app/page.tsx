import type { Metadata } from "next";
import { HomepageView } from "@/components/HomepageView";
import { homepageContract } from "@/lib/industries";
import { metadataFromContract } from "@/lib/seo";

export const metadata: Metadata = metadataFromContract(homepageContract);

export default function HomePage() {
  return <HomepageView page={homepageContract} />;
}
