import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CategoryPageView } from "@/components/CategoryPageView";
import { IndustryPageView } from "@/components/IndustryPageView";
import {
  getAllStaticParams,
  getRouteContract,
} from "@/lib/industries";
import { metadataFromContract } from "@/lib/seo";

export const dynamicParams = false;

export function generateStaticParams() {
  return getAllStaticParams();
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string[] }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const contract = getRouteContract(slug);

  if (!contract || contract.kind === "homepage") {
    return {};
  }

  return metadataFromContract(contract.page);
}

export default async function DynamicIndustryRoute({
  params,
}: {
  params: Promise<{ slug: string[] }>;
}) {
  const { slug } = await params;
  const contract = getRouteContract(slug);

  if (!contract || contract.kind === "homepage") {
    notFound();
  }

  if (contract.kind === "category") {
    return <CategoryPageView page={contract.page} />;
  }

  return <IndustryPageView page={contract.page} />;
}
