import type { MetadataRoute } from "next";
import { pagesManifest } from "@/lib/industries";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = pagesManifest.canonicalBaseUrl.replace(/\/$/, "");

  return pagesManifest.pages.map((entry) => ({
    url: entry.route === "/" ? `${base}/` : `${base}${entry.route}`,
    changeFrequency:
      entry.type === "homepage"
        ? "weekly"
        : entry.type === "category"
          ? "weekly"
          : "monthly",
    priority:
      entry.type === "homepage"
        ? 1
        : entry.type === "category"
          ? 0.85
          : 0.72,
  }));
}
