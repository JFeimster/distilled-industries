import type { Metadata, Viewport } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { TickerRail } from "@/components/TickerRail";
import { assertRuntimeIntegrity } from "@/lib/validation";
import { assertManifestSeoIntegrity } from "@/lib/seo-guard";

assertRuntimeIntegrity();
assertManifestSeoIntegrity();

export const metadata: Metadata = {
  metadataBase: new URL("https://industries.distilledfunding.com"),
  title: {
    default: "Business Funding by Industry | Distilled Funding",
    template: "%s | Distilled Funding",
  },
  description:
    "Industry-specific funding guides built around real cash cycles, capital uses, documentation, and underwriting signals.",
  applicationName: "Distilled Funding Industries",
  creator: "Distilled Funding",
  publisher: "Distilled Funding",
};

export const viewport: Viewport = {
  themeColor: "#080808",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <SiteHeader />
        <TickerRail />
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
