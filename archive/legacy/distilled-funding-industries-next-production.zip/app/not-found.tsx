import Link from "next/link";

export default function NotFound() {
  return (
    <main className="heroSection">
      <div className="shell">
        <div className="eyebrow">404 // ROUTE LOST</div>
        <h1>THIS CAPITAL LANE DOESN&apos;T EXIST.</h1>
        <p className="heroCopy">Return to the industry directory and choose a live route.</p>
        <Link className="button buttonGold" href="/">Open Industry Directory</Link>
      </div>
    </main>
  );
}
