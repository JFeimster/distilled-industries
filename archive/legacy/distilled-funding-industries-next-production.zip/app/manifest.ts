import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Distilled Funding — Industries",
    short_name: "DF Industries",
    description:
      "Industry-specific capital intelligence built around real operating cash cycles.",
    start_url: "/",
    display: "standalone",
    background_color: "#080808",
    theme_color: "#080808",
  };
}
