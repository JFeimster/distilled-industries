# Deployment — Distilled Funding Industries

## Target

- Repository: `JFeimster/distilled-funding-industries`
- Vercel project: `distilled-funding-industries`
- Production domain: `industries.distilledfunding.com`

## Local verification

```powershell
npm install
npm run typecheck
npm run validate
npm run build
```

The build pre-renders the 115 non-root manifest routes plus the root homepage through the App Router.

## GitHub

```powershell
git init
git add .
git commit -m "Launch Distilled Funding Industries property"
git branch -M main
gh repo create JFeimster/distilled-funding-industries --public --source=. --remote=origin --push
```

## Vercel

From the project directory:

```powershell
vercel
vercel --prod
```

Bind `industries.distilledfunding.com` to the resulting Vercel project in the production domain configuration.

## Production checks

- `/`
- `/construction`
- `/construction/hvac`
- `/ecommerce/amazon-sellers`
- `/real-estate/fix-and-flip`
- `/sitemap.xml`
- `/robots.txt`

## Canonical conversion target

`https://www.distilledfunding.com/apply`
