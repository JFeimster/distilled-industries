# Distilled Funding Industries

Production industry-capital property for `industries.distilledfunding.com`.

## Architecture

**Next.js App Router + TypeScript + JSON page contracts + static generation + Vercel**

The canonical manifest drives:

- 1 homepage
- 15 sector/category hubs
- 100 industry pages
- 116 unique routes
- navigation
- internal linking
- metadata
- JSON-LD
- sitemap
- robots

## Commands

```powershell
npm install
npm run typecheck
npm run validate
npm run build
npm run audit
```

## Core production files

- `data/industries-homepage.production.json`
- `data/industries.pages.manifest.json`
- `data/industries.navigation.manifest.json`
- `data/industries-page.template.json`
- `data/industries.design-system.json`
- `CANONICAL-SITEMAP.txt`
- `BATCH-AUDIT.json`
- `validate-industries-pages.cjs`
- `validate-funding-pages.cjs`

## Rendering model

The codebase does not maintain 100 hand-coded pages. It resolves every route from the canonical page manifest and renders the appropriate category or industry contract through reusable production components.

## Design

Variation 3:

**BOLD × IMPACTFUL × BRAND FORWARD × NEO-BRUTALIST × CAPITAL COMMAND DESK × FIELD MANUAL × TRADING TERMINAL**

## Conversion

Primary application URL:

`https://www.distilledfunding.com/apply`
