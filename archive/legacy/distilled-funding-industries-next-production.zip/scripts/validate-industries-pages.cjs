#!/usr/bin/env node
const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const manifest = JSON.parse(
  fs.readFileSync(path.join(root, "data", "industries.pages.manifest.json"), "utf8")
);

const failures = [];
const warnings = [];
const routeSet = new Set();
const canonicalSet = new Set();
const forbiddenPublicClaims = [
  "guaranteed approval",
  "guaranteed funding",
  "no documentation required",
  "instant approval for all applicants",
];

const knownProviderNames = [
  "Bank Breezy",
  "David Allen Capital",
  "8fig",
  "Credibly",
  "7 Figures Funding",
];

function read(rel) {
  const absolute = path.join(root, rel);
  if (!fs.existsSync(absolute)) {
    failures.push(`Missing file: ${rel}`);
    return null;
  }
  try {
    return JSON.parse(fs.readFileSync(absolute, "utf8"));
  } catch (error) {
    failures.push(`Invalid JSON: ${rel}: ${error.message}`);
    return null;
  }
}

function strings(value, output = []) {
  if (typeof value === "string") output.push(value);
  else if (Array.isArray(value)) value.forEach((item) => strings(item, output));
  else if (value && typeof value === "object") {
    Object.entries(value).forEach(([key, item]) => {
      if (key === "forbiddenClaims") return;
      strings(item, output);
    });
  }
  return output;
}

let homepage = 0;
let categories = 0;
let industries = 0;

for (const entry of manifest.pages) {
  if (routeSet.has(entry.route)) failures.push(`Duplicate route: ${entry.route}`);
  routeSet.add(entry.route);

  const doc = read(entry.source);
  if (!doc) continue;

  if (entry.type === "homepage") homepage++;
  if (entry.type === "category") categories++;
  if (entry.type === "industry") industries++;

  if (doc.route !== entry.route) {
    failures.push(`Route mismatch: ${entry.source} -> ${doc.route} != ${entry.route}`);
  }

  const canonical = doc.seo?.canonical;
  if (!canonical) {
    failures.push(`Missing canonical: ${entry.source}`);
  } else {
    if (canonicalSet.has(canonical)) failures.push(`Duplicate canonical: ${canonical}`);
    canonicalSet.add(canonical);

    const expected =
      entry.route === "/"
        ? `${manifest.canonicalBaseUrl.replace(/\/$/, "")}/`
        : `${manifest.canonicalBaseUrl.replace(/\/$/, "")}${entry.route}`;

    if (canonical !== expected) {
      failures.push(`Canonical mismatch: ${entry.source} -> ${canonical} != ${expected}`);
    }
  }

  const publicText = strings(doc).join("\n").toLowerCase();

  for (const claim of forbiddenPublicClaims) {
    if (publicText.includes(claim)) {
      failures.push(`Forbidden claim "${claim}" in ${entry.source}`);
    }
  }

  if (entry.type === "industry") {
    const required = [
      "id",
      "slug",
      "route",
      "categoryId",
      "categorySlug",
      "categoryLabel",
      "label",
      "pageType",
      "status",
      "seo",
      "hero",
      "operatingReality",
      "capitalUseCases",
      "recommendedFundingPaths",
      "qualificationSnapshot",
      "faq",
      "relatedIndustries",
      "compliance",
      "dataRefs",
    ];

    required.forEach((field) => {
      if (!(field in doc)) failures.push(`Missing ${field}: ${entry.source}`);
    });

    if ((doc.capitalUseCases || []).length < 3) failures.push(`Too few capital use cases: ${entry.source}`);
    if ((doc.recommendedFundingPaths || []).length < 2) failures.push(`Too few funding lanes: ${entry.source}`);
    if ((doc.faq || []).length < 3) failures.push(`Too few FAQs: ${entry.source}`);
    if ((doc.relatedIndustries || []).length < 2) failures.push(`Too few related links: ${entry.source}`);

    for (const provider of knownProviderNames) {
      if (publicText.includes(provider.toLowerCase())) {
        failures.push(`Provider leakage "${provider}" in ${entry.source}`);
      }
    }
  }
}

if (homepage !== 1) failures.push(`Expected homepage=1, got ${homepage}`);
if (categories !== 15) failures.push(`Expected categories=15, got ${categories}`);
if (industries !== 100) failures.push(`Expected industries=100, got ${industries}`);
if (routeSet.size !== 116) failures.push(`Expected unique routes=116, got ${routeSet.size}`);
if (canonicalSet.size !== 116) failures.push(`Expected unique canonicals=116, got ${canonicalSet.size}`);

const requiredSiteFiles = [
  "app/layout.tsx",
  "app/page.tsx",
  "app/[...slug]/page.tsx",
  "app/sitemap.ts",
  "app/robots.ts",
  "app/manifest.ts",
  "app/globals.css",
  "lib/industries.ts",
  "lib/seo.ts",
  "lib/schema.ts",
  "lib/navigation.ts",
  "components/HomepageView.tsx",
  "components/CategoryPageView.tsx",
  "components/IndustryPageView.tsx",
];

for (const rel of requiredSiteFiles) {
  if (!fs.existsSync(path.join(root, rel))) failures.push(`Missing site file: ${rel}`);
}

const result = {
  ok: failures.length === 0,
  counts: {
    homepage,
    categories,
    industries,
    routes: routeSet.size,
    canonicals: canonicalSet.size,
  },
  qa: {
    providerLeakage: failures.filter((x) => x.startsWith("Provider leakage")).length,
    forbiddenClaimViolations: failures.filter((x) => x.startsWith("Forbidden claim")).length,
    requiredSiteFilesPresent: requiredSiteFiles.length,
  },
  warnings,
  failures,
};

console.log(JSON.stringify(result, null, 2));
if (failures.length) process.exit(1);
