import type { CategoryPage, HomepageContract, IndustryPage } from "@/lib/types";

const baseUrl = "https://industries.distilledfunding.com";
const organizationId = "https://www.distilledfunding.com/#organization";

const organization = {
  "@type": "Organization",
  "@id": organizationId,
  name: "Distilled Funding",
  url: "https://www.distilledfunding.com/",
};

export function homepageSchema(page: HomepageContract) {
  return {
    "@context": "https://schema.org",
    "@graph": [
      organization,
      {
        "@type": "WebSite",
        "@id": `${baseUrl}/#website`,
        name: "Distilled Funding Industries",
        url: `${baseUrl}/`,
        publisher: { "@id": organizationId },
      },
      {
        "@type": "CollectionPage",
        "@id": `${page.seo.canonical}#webpage`,
        name: page.seo.title,
        url: page.seo.canonical,
        description: page.seo.description,
        isPartOf: { "@id": `${baseUrl}/#website` },
        publisher: { "@id": organizationId },
        mainEntity: {
          "@type": "ItemList",
          numberOfItems: page.categories.length,
          itemListElement: page.categories.map((category, index) => ({
            "@type": "ListItem",
            position: index + 1,
            name: category.label,
            url: `${baseUrl}${category.route}`,
          })),
        },
      },
    ],
  };
}

export function categorySchema(page: CategoryPage) {
  return {
    "@context": "https://schema.org",
    "@graph": [
      organization,
      {
        "@type": "CollectionPage",
        "@id": `${page.seo.canonical}#webpage`,
        name: page.seo.title,
        url: page.seo.canonical,
        description: page.seo.description,
        isPartOf: { "@id": `${baseUrl}/#website` },
        publisher: { "@id": organizationId },
        mainEntity: {
          "@type": "ItemList",
          numberOfItems: page.industries.length,
          itemListElement: page.industries.map((industry, index) => ({
            "@type": "ListItem",
            position: index + 1,
            name: industry.label,
            url: `${baseUrl}${industry.route}`,
          })),
        },
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${page.seo.canonical}#breadcrumbs`,
        itemListElement: [
          {
            "@type": "ListItem",
            position: 1,
            name: "Industries",
            item: `${baseUrl}/`,
          },
          {
            "@type": "ListItem",
            position: 2,
            name: page.label,
            item: page.seo.canonical,
          },
        ],
      },
    ],
  };
}

export function industrySchema(page: IndustryPage) {
  const webpageId = `${page.seo.canonical}#webpage`;
  const faqId = `${page.seo.canonical}#faq`;

  return {
    "@context": "https://schema.org",
    "@graph": [
      organization,
      {
        "@type": "WebPage",
        "@id": webpageId,
        name: page.seo.title,
        url: page.seo.canonical,
        description: page.seo.description,
        isPartOf: { "@id": `${baseUrl}/#website` },
        publisher: { "@id": organizationId },
        breadcrumb: { "@id": `${page.seo.canonical}#breadcrumbs` },
        mainEntity: { "@id": faqId },
        about: {
          "@type": "Thing",
          name: page.label,
          description: `${page.label} capital needs, operating cash cycle, documentation, and funding-path considerations.`,
        },
      },
      {
        "@type": "BreadcrumbList",
        "@id": `${page.seo.canonical}#breadcrumbs`,
        itemListElement: [
          {
            "@type": "ListItem",
            position: 1,
            name: "Industries",
            item: `${baseUrl}/`,
          },
          {
            "@type": "ListItem",
            position: 2,
            name: page.categoryLabel,
            item: `${baseUrl}/${page.categorySlug}`,
          },
          {
            "@type": "ListItem",
            position: 3,
            name: page.label,
            item: page.seo.canonical,
          },
        ],
      },
      {
        "@type": "FAQPage",
        "@id": faqId,
        mainEntity: page.faq.map((item) => ({
          "@type": "Question",
          name: item.question,
          acceptedAnswer: {
            "@type": "Answer",
            text: item.answer,
          },
        })),
      },
    ],
  };
}
