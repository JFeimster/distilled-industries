import { pagesManifest } from "@/lib/industries";
import { siteConfig } from "@/lib/site-config";

export function assertCanonical(route: string, canonical: string) {
  const base = siteConfig.canonicalBaseUrl.replace(/\/$/, "");
  const expected = route === "/" ? `${base}/` : `${base}${route}`;

  if (canonical !== expected) {
    throw new Error(
      `Canonical mismatch for ${route}: expected ${expected}, received ${canonical}`
    );
  }
}

export function assertManifestSeoIntegrity() {
  const routes = new Set<string>();
  for (const entry of pagesManifest.pages) {
    if (routes.has(entry.route)) {
      throw new Error(`Duplicate route in manifest: ${entry.route}`);
    }
    routes.add(entry.route);
  }
}
