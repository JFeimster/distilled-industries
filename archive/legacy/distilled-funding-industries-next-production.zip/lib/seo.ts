import type { Metadata } from "next";
import type { CategoryPage, HomepageContract, IndustryPage } from "@/lib/types";
import { assertCanonical } from "@/lib/seo-guard";

type SeoCarrier = HomepageContract | CategoryPage | IndustryPage;

export function metadataFromContract(page: SeoCarrier): Metadata {
  const seo = page.seo;
  assertCanonical(page.route, seo.canonical);

  const cleanTitle = seo.title.replace(/\s+\|\s+Distilled Funding$/i, "");

  return {
    title: cleanTitle,
    description: seo.description,
    alternates: {
      canonical: seo.canonical,
    },
    openGraph: {
      type: "website",
      url: seo.canonical,
      title: seo.ogTitle ?? seo.title,
      description: seo.ogDescription ?? seo.description,
      siteName: "Distilled Funding",
      locale: "en_US",
    },
    twitter: {
      card: "summary_large_image",
      title: seo.ogTitle ?? seo.title,
      description: seo.ogDescription ?? seo.description,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-image-preview": "large",
        "max-snippet": -1,
        "max-video-preview": -1,
      },
    },
    category:
      page.pageType === "industry-funding"
        ? page.categoryLabel
        : page.pageType === "industry-category"
          ? page.label
          : "Business Funding",
  };
}
