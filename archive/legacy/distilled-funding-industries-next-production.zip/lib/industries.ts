import fs from "node:fs";
import path from "node:path";
import type { CategoryPage, HomepageContract, IndustryPage } from "@/lib/types";

type ManifestEntry = {
  id: string;
  route: string;
  type: "homepage" | "category" | "industry";
  source: string;
};

type PagesManifest = {
  id: string;
  name: string;
  version: string;
  canonicalBaseUrl: string;
  counts: {
    homepage: number;
    categories: number;
    industries: number;
    totalRoutes: number;
  };
  pages: ManifestEntry[];
};

const root = process.cwd();

function readJson<T>(relativePath: string): T {
  return JSON.parse(
    fs.readFileSync(path.join(root, relativePath), "utf8")
  ) as T;
}

export const pagesManifest = readJson<PagesManifest>(
  "data/industries.pages.manifest.json"
);

export const homepageContract = readJson<HomepageContract>(
  "data/industries-homepage.production.json"
);

const categoryEntries = pagesManifest.pages.filter(
  (entry) => entry.type === "category"
);

const industryEntries = pagesManifest.pages.filter(
  (entry) => entry.type === "industry"
);

export const categoryPages = categoryEntries.map((entry) =>
  readJson<CategoryPage>(entry.source)
);

export const industryPages = industryEntries.map((entry) =>
  readJson<IndustryPage>(entry.source)
);

export const categoryByRoute = new Map(
  categoryPages.map((page) => [page.route, page])
);

export const industryByRoute = new Map(
  industryPages.map((page) => [page.route, page])
);

export function normalizeRoute(parts: string[] | undefined): string {
  if (!parts || parts.length === 0) return "/";
  return `/${parts.map((part) => part.trim()).filter(Boolean).join("/")}`;
}

export function getRouteContract(parts: string[] | undefined):
  | { kind: "homepage"; page: HomepageContract }
  | { kind: "category"; page: CategoryPage }
  | { kind: "industry"; page: IndustryPage }
  | null {
  const route = normalizeRoute(parts);
  if (route === "/") return { kind: "homepage", page: homepageContract };

  const category = categoryByRoute.get(route);
  if (category) return { kind: "category", page: category };

  const industry = industryByRoute.get(route);
  if (industry) return { kind: "industry", page: industry };

  return null;
}

export function getAllStaticParams(): Array<{ slug: string[] }> {
  return pagesManifest.pages
    .filter((entry) => entry.route !== "/")
    .map((entry) => ({
      slug: entry.route.split("/").filter(Boolean),
    }));
}

export function getIndustrySearchIndex() {
  return industryPages.map((page) => ({
    slug: page.slug,
    route: page.route,
    label: page.label,
    categoryLabel: page.categoryLabel,
    categorySlug: page.categorySlug,
    keywords: [
      page.label,
      page.categoryLabel,
      ...page.capitalUseCases.map((item) => item.title),
      ...page.recommendedFundingPaths.map((item) => item.label),
    ]
      .join(" ")
      .toLowerCase(),
  }));
}

export function getCategoryBySlug(slug: string) {
  return categoryPages.find((page) => page.slug === slug) ?? null;
}

export function getIndustryBySlug(categorySlug: string, industrySlug: string) {
  return (
    industryPages.find(
      (page) =>
        page.categorySlug === categorySlug && page.slug === industrySlug
    ) ?? null
  );
}
