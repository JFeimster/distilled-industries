import fs from "node:fs";
import path from "node:path";

type NavigationItem = {
  label: string;
  href: string;
  children?: Array<{ label: string; href: string }>;
};

type NavigationManifest = {
  id: string;
  version: string;
  brand: {
    label: string;
    home: string;
    mainSite: string;
  };
  primary: NavigationItem[];
  utility: NavigationItem[];
};

export const navigationManifest = JSON.parse(
  fs.readFileSync(
    path.join(process.cwd(), "data/industries.navigation.manifest.json"),
    "utf8"
  )
) as NavigationManifest;
