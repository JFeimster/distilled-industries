export type Cta = {
  label: string;
  href: string;
};

export type SeoBlock = {
  title: string;
  description: string;
  canonical: string;
  ogTitle?: string;
  ogDescription?: string;
  schemaTypes?: string[];
};

export type IndustryLink = {
  label: string;
  route: string;
};

export type FundingPath = {
  rank?: number;
  familySlug: string;
  label: string;
  rationale: string;
};

export type IndustryPage = {
  schema_version: string;
  id: string;
  slug: string;
  route: string;
  categoryId: string;
  categorySlug: string;
  categoryLabel: string;
  label: string;
  pageType: "industry-funding";
  status: string;
  visibility?: string;
  seo: SeoBlock;
  hero: {
    eyebrow: string;
    headline: string;
    subheadline: string;
    primaryCta: Cta;
    secondaryCta: Cta;
  };
  operatingReality: {
    title: string;
    summary: string;
    painPoints: Array<{ number: string; title: string; body: string }>;
  };
  capitalUseCases: Array<{
    number: string;
    title: string;
    body: string;
    fundingFamily: string;
  }>;
  recommendedFundingPaths: FundingPath[];
  qualificationSnapshot: {
    title: string;
    signals: string[];
    commonDocuments: Array<{ documentKey: string; label: string }>;
    fastDisqualifiers?: string[];
  };
  toolsAndResources?: {
    scorecardId?: string;
    toolIds?: string[];
    gptIds?: string[];
    primaryApplicationUrl?: string;
  };
  faq: Array<{ question: string; answer: string }>;
  relatedIndustries: IndustryLink[];
  compliance: {
    disclaimer: string;
  };
};

export type CategoryPage = {
  schema_version: string;
  id: string;
  slug: string;
  route: string;
  label: string;
  pageType: "industry-category";
  status: string;
  seo: SeoBlock;
  hero: {
    eyebrow: string;
    headline: string;
    subheadline: string;
    primaryCta: Cta;
  };
  industryCount: number;
  industries: Array<{ slug: string; label: string; route: string; hook: string }>;
  fundingPaths: FundingPath[];
  compliance: {
    disclaimer: string;
  };
};

export type HomepageContract = {
  schema_version: string;
  id: string;
  route: string;
  pageType: "industries-homepage";
  status: string;
  seo: SeoBlock;
  hero: {
    eyebrow: string;
    headline: string;
    subheadline: string;
    primaryCta: Cta;
    searchPlaceholder: string;
  };
  stats: Array<{ value: string; label: string }>;
  categories: Array<{
    id: string;
    slug: string;
    label: string;
    route: string;
    industryCount: number;
    hook: string;
  }>;
  primaryApplicationUrl: string;
  compliance: { disclaimer: string };
};
