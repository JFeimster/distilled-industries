import fs from "node:fs";
import path from "node:path";

type SiteConfig = {
  siteId: string;
  brand: string;
  property: string;
  canonicalBaseUrl: string;
  mainSiteUrl: string;
  primaryApplicationUrl: string;
  defaultTitleSuffix: string;
  disclaimer: string;
  publicProviderExposure: boolean;
};

export const siteConfig = JSON.parse(
  fs.readFileSync(
    path.join(process.cwd(), "data/site.config.json"),
    "utf8"
  )
) as SiteConfig;
