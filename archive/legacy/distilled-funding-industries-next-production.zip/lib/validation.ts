import { categoryPages, homepageContract, industryPages, pagesManifest } from "@/lib/industries";

export function assertRuntimeIntegrity() {
  const failures: string[] = [];

  if (pagesManifest.counts.homepage !== 1) {
    failures.push(`Expected 1 homepage; got ${pagesManifest.counts.homepage}`);
  }
  if (categoryPages.length !== 15) {
    failures.push(`Expected 15 categories; got ${categoryPages.length}`);
  }
  if (industryPages.length !== 100) {
    failures.push(`Expected 100 industries; got ${industryPages.length}`);
  }
  if (pagesManifest.pages.length !== 116) {
    failures.push(`Expected 116 routes; got ${pagesManifest.pages.length}`);
  }

  const routes = new Set<string>();
  for (const entry of pagesManifest.pages) {
    if (routes.has(entry.route)) failures.push(`Duplicate route: ${entry.route}`);
    routes.add(entry.route);
  }

  if (homepageContract.route !== "/") failures.push("Homepage route must be /");

  if (failures.length) {
    throw new Error(`Industries data integrity failed:\n${failures.join("\n")}`);
  }
}
