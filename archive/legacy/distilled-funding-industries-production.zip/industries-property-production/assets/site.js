(function(){
  const input=document.querySelector('[data-industry-search]');
  if(!input) return;
  const items=[...document.querySelectorAll('[data-industry-item]')];
  const count=document.querySelector('[data-result-count]');
  input.addEventListener('input',()=>{
    const q=input.value.trim().toLowerCase();
    let visible=0;
    items.forEach(el=>{
      const match=!q || el.textContent.toLowerCase().includes(q) || (el.dataset.keywords||'').includes(q);
      el.style.display=match?'':'none';
      if(match) visible++;
    });
    if(count) count.textContent=visible+' matches';
  });
})();
