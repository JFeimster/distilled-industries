#!/usr/bin/env node
// Contracts are committed in generated form. This script is intentionally conservative:
// it validates the seed registry shape and instructs maintainers to use the committed
// Python/AI generation workflow when changing prose-heavy seed content.
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const seeds = JSON.parse(fs.readFileSync(path.join(root,'data','industries-seeds.registry.json'),'utf8'));
const categories = seeds.categories || [];
const industries = categories.flatMap(c => c.industries || []);
if (categories.length !== 15) throw new Error(`Expected 15 categories; got ${categories.length}`);
if (industries.length !== 100) throw new Error(`Expected 100 industries; got ${industries.length}`);
console.log(`Seed registry ready: ${categories.length} categories / ${industries.length} industries.`);
console.log('Page contracts are already generated and committed. Run npm run validate && npm run build.');
