#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname,'..');
const dist = path.join(root,'dist');
const data = path.join(root,'data');
const esc = s => String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const read = rel => JSON.parse(fs.readFileSync(path.join(root,rel),'utf8'));
const manifest = read('data/industries.pages.manifest.json');
const nav = read('data/industries.navigation.manifest.json');
const config = read('data/site.config.json');

fs.rmSync(dist,{recursive:true,force:true});
fs.mkdirSync(dist,{recursive:true});
fs.mkdirSync(path.join(dist,'assets'),{recursive:true});
fs.copyFileSync(path.join(root,'assets','site.css'),path.join(dist,'assets','site.css'));
fs.copyFileSync(path.join(root,'assets','site.js'),path.join(dist,'assets','site.js'));

function writeRoute(route, html){
  const target = route==='/' ? dist : path.join(dist, ...route.split('/').filter(Boolean));
  fs.mkdirSync(target,{recursive:true});
  fs.writeFileSync(path.join(target,'index.html'),html);
}
function header(){
  return `<a class="skip" href="#main">Skip to content</a>
<header class="topbar"><div class="wrap"><a class="brand" href="/">DISTILLED <span>FUNDING</span> // INDUSTRIES</a>
<nav class="nav"><a href="/">Directory</a><a href="${esc(config.mainSiteUrl)}">Main Site</a><a class="btn gold" href="${esc(config.primaryApplicationUrl)}">Check Options</a></nav></div></header>`;
}
function footer(){
  return `<footer class="footer"><div class="wrap">© ${new Date().getFullYear()} Distilled Funding // Industry Capital Directory<br>${esc(config.disclaimer)}</div></footer>`;
}
function ticker(){
  const text='UNDERSTAND THE FILE • MATCH THE CAPITAL LANE • KILL BAD FIT EARLY • DOCUMENT THE STORY • FUND THE REAL CASH CYCLE • ';
  return `<div class="ticker"><div>${text.repeat(4)}</div></div>`;
}
function schemaTag(obj){ return `<script type="application/ld+json">${JSON.stringify(obj).replace(/</g,'\\u003c')}</script>`; }
function baseDoc(meta, body, schema){
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(meta.title)}</title><meta name="description" content="${esc(meta.description)}"><link rel="canonical" href="${esc(meta.canonical)}">
<meta property="og:type" content="website"><meta property="og:title" content="${esc(meta.ogTitle||meta.title)}"><meta property="og:description" content="${esc(meta.ogDescription||meta.description)}"><meta property="og:url" content="${esc(meta.canonical)}">
<link rel="stylesheet" href="/assets/site.css">${schemaTag(schema)}</head><body>${header()}${ticker()}<main id="main">${body}</main>${footer()}<script src="/assets/site.js" defer></script></body></html>`;
}
function breadcrumbs(items){
  return `<div class="wrap breadcrumbs">${items.map((x,i)=>i===items.length-1?esc(x.label):`<a href="${x.href}">${esc(x.label)}</a>`).join(' / ')}</div>`;
}
function homepage(doc){
  const categories = doc.categories.map(c=>`<a class="card category-card cyan" href="${c.route}" data-industry-item data-keywords="${esc(c.label.toLowerCase())}">
  <div><div class="count">${String(c.industryCount).padStart(2,'0')} GUIDES</div><h3>${esc(c.label)}</h3><p>${esc(c.hook)}</p></div><b>OPEN SECTOR →</b></a>`).join('');
  const industryItems = nav.primary.flatMap(c=>c.children.map(i=>`<a class="industry-link" href="${i.href}" data-industry-item data-keywords="${esc((c.label+' '+i.label).toLowerCase())}">${esc(i.label)} <span>→</span></a>`)).join('');
  const body = `<section class="hero"><div class="wrap"><div class="kicker">${esc(doc.hero.eyebrow)}</div><h1>${esc(doc.hero.headline)}</h1><p>${esc(doc.hero.subheadline)}</p><div class="hero-actions"><a class="btn gold" href="${esc(doc.hero.primaryCta.href)}">${esc(doc.hero.primaryCta.label)}</a></div></div></section>
  <section class="stats">${doc.stats.map(s=>`<div class="stat"><b>${esc(s.value)}</b><span>${esc(s.label)}</span></div>`).join('')}</section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>CHOOSE THE SECTOR.</h2><p>Start with the operating model. Then drill down to the industry page that matches how cash actually moves.</p></div><div class="grid">${categories}</div></div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>SEARCH ALL 100.</h2><p data-result-count>100 matches</p></div><input class="search" data-industry-search placeholder="${esc(doc.hero.searchPlaceholder)}"><div class="industry-index">${industryItems}</div></div></section>
  <section class="cta"><div class="wrap"><div class="kicker">CAPITAL ROUTING // NOT APPLICATION ROULETTE</div><h2>YOU DON'T NEED MORE APPLICATIONS. YOU NEED THE RIGHT LANE.</h2><p>${esc(doc.compliance.disclaimer)}</p><a class="btn gold" href="${esc(doc.primaryApplicationUrl)}">CHECK FUNDING OPTIONS</a></div></section>`;
  const schema={"@context":"https://schema.org","@type":"CollectionPage","name":doc.seo.title,"url":doc.seo.canonical,"description":doc.seo.description};
  return baseDoc(doc.seo,body,schema);
}
function category(doc){
  const cards=doc.industries.map((i,idx)=>`<a class="card category-card" href="${i.route}"><div><div class="num">${String(idx+1).padStart(2,'0')}</div><h3>${esc(i.label)}</h3><p>${esc(i.hook)}</p></div><b>OPEN GUIDE →</b></a>`).join('');
  const lanes=doc.fundingPaths.map((x,i)=>`<div class="lane"><div class="rank">LANE ${String(i+1).padStart(2,'0')}</div><h3>${esc(x.label)}</h3><p>${esc(x.rationale)}</p></div>`).join('');
  const body = `${breadcrumbs([{label:'Industries',href:'/'},{label:doc.label}])}<section class="hero"><div class="wrap"><div class="kicker">${esc(doc.hero.eyebrow)}</div><h1>${esc(doc.hero.headline)}</h1><p>${esc(doc.hero.subheadline)}</p><div class="hero-actions"><a class="btn gold" href="${esc(doc.hero.primaryCta.href)}">${esc(doc.hero.primaryCta.label)}</a></div></div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>${esc(doc.industryCount)} INDUSTRY GUIDES.</h2><p>Choose the operating model closest to the file. Each guide maps capital uses, documentation, underwriting signals, and realistic funding lanes.</p></div><div class="grid">${cards}</div></div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>THE CAPITAL LANES.</h2><p>These are the most relevant starting points for this sector. Fit still depends on the actual file.</p></div><div class="lanes">${lanes}</div></div></section>
  <section class="cta"><div class="wrap"><div class="kicker">READY TO ROUTE THE FILE?</div><h2>FUND THE OPERATING REALITY.</h2><p>${esc(doc.compliance.disclaimer)}</p><a class="btn gold" href="${esc(doc.hero.primaryCta.href)}">CHECK FUNDING OPTIONS</a></div></section>`;
  const schema={"@context":"https://schema.org","@type":"CollectionPage","name":doc.seo.title,"url":doc.seo.canonical,"description":doc.seo.description};
  return baseDoc(doc.seo,body,schema);
}
function industry(doc){
  const pains=doc.operatingReality.painPoints.map(x=>`<div class="card gold"><div class="num">${esc(x.number)}</div><h3>${esc(x.title)}</h3><p>${esc(x.body)}</p></div>`).join('');
  const uses=doc.capitalUseCases.map(x=>`<div class="card"><div class="num">${esc(x.number)}</div><h3>${esc(x.title)}</h3><p>${esc(x.body)}</p></div>`).join('');
  const lanes=doc.recommendedFundingPaths.map(x=>`<div class="lane"><div class="rank">PRIORITY ${String(x.rank).padStart(2,'0')}</div><h3>${esc(x.label)}</h3><p>${esc(x.rationale)}</p></div>`).join('');
  const signals=doc.qualificationSnapshot.signals.map(x=>`<li>${esc(x)}</li>`).join('');
  const docs=doc.qualificationSnapshot.commonDocuments.map(x=>`<li>${esc(x.label)}</li>`).join('');
  const faqs=doc.faq.map(x=>`<details><summary>${esc(x.question)}</summary><p>${esc(x.answer)}</p></details>`).join('');
  const related=doc.relatedIndustries.map(x=>`<a href="${x.route}">${esc(x.label)} →</a>`).join('');
  const body = `${breadcrumbs([{label:'Industries',href:'/'},{label:doc.categoryLabel,href:'/'+doc.categorySlug},{label:doc.label}])}
  <section class="hero"><div class="wrap"><div class="kicker">${esc(doc.hero.eyebrow)}</div><h1>${esc(doc.hero.headline)}</h1><p>${esc(doc.hero.subheadline)}</p><div class="hero-actions"><a class="btn gold" href="${esc(doc.hero.primaryCta.href)}">${esc(doc.hero.primaryCta.label)}</a><a class="btn" href="${esc(doc.hero.secondaryCta.href)}">${esc(doc.hero.secondaryCta.label)}</a></div></div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>${esc(doc.operatingReality.title)}</h2><p>${esc(doc.operatingReality.summary)}</p></div><div class="grid">${pains}</div></div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>WHERE CAPITAL ACTUALLY GOES.</h2><p>Use-of-funds comes first. The funding lane follows the operating problem—not the other way around.</p></div><div class="grid">${uses}</div></div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>CAPITAL LANES.</h2><p>Ranked starting points for this industry. Qualification and economics still depend on the file.</p></div><div class="lanes">${lanes}</div></div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>UNDERWRITING FIELD MANUAL.</h2><p>Bring the facts that let a strategist kill bad-fit lanes early and protect the good ones.</p></div><div class="field-manual"><div class="manual-panel"><h3>THE SIGNALS</h3><ul>${signals}</ul></div><div class="manual-panel"><h3>BRING THE PAPER</h3><ul>${docs}</ul></div></div></div></section>
  <section class="section faq"><div class="wrap"><div class="section-head"><h2>FAST QUESTIONS.</h2><p>No fantasy underwriting. Just the practical questions that determine fit.</p></div>${faqs}</div></section>
  <section class="section"><div class="wrap"><div class="section-head"><h2>RELATED INDUSTRIES.</h2><p>Adjacent operating models, similar cash cycles, and useful internal-link paths.</p></div><div class="related">${related}</div></div></section>
  <section class="cta"><div class="wrap"><div class="kicker">THE NEXT MOVE</div><h2>UNDERSTAND THE FILE. THEN CHOOSE THE CAPITAL.</h2><p>${esc(doc.compliance.disclaimer)}</p><a class="btn gold" href="${esc(doc.hero.primaryCta.href)}">${esc(doc.hero.primaryCta.label)}</a></div></section>`;
  const schema={
    "@context":"https://schema.org",
    "@graph":[
      {"@type":"WebPage","name":doc.seo.title,"url":doc.seo.canonical,"description":doc.seo.description},
      {"@type":"BreadcrumbList","itemListElement":[
        {"@type":"ListItem","position":1,"name":"Industries","item":config.canonicalBaseUrl+"/"},
        {"@type":"ListItem","position":2,"name":doc.categoryLabel,"item":config.canonicalBaseUrl+"/"+doc.categorySlug},
        {"@type":"ListItem","position":3,"name":doc.label,"item":doc.seo.canonical}
      ]},
      {"@type":"FAQPage","mainEntity":doc.faq.map(x=>({"@type":"Question","name":x.question,"acceptedAnswer":{"@type":"Answer","text":x.answer}}))}
    ]
  };
  return baseDoc(doc.seo,body,schema);
}

for(const entry of manifest.pages){
  const doc=read(entry.source);
  let out;
  if(entry.type==='homepage') out=homepage(doc);
  else if(entry.type==='category') out=category(doc);
  else out=industry(doc);
  writeRoute(entry.route,out);
}

const urls = manifest.pages.map(x=>config.canonicalBaseUrl.replace(/\/$/,'')+(x.route==='/'?'/':x.route));
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u=>`  <url><loc>${u}</loc></url>`).join('\n')}\n</urlset>\n`;
fs.writeFileSync(path.join(dist,'sitemap.xml'),sitemap);
fs.writeFileSync(path.join(dist,'robots.txt'),`User-agent: *\nAllow: /\nSitemap: ${config.canonicalBaseUrl}/sitemap.xml\n`);
fs.writeFileSync(path.join(dist,'404.html'),baseDoc(
  {title:'Page Not Found | Distilled Funding',description:'The requested industry guide could not be found.',canonical:config.canonicalBaseUrl+'/404'},
  `<section class="hero"><div class="wrap"><div class="kicker">404 // ROUTE LOST</div><h1>THIS CAPITAL LANE DOESN'T EXIST.</h1><p>Return to the industry directory and pick a real route.</p><a class="btn gold" href="/">OPEN INDUSTRY DIRECTORY</a></div></section>`,
  {"@context":"https://schema.org","@type":"WebPage","name":"Page Not Found"}
));

console.log(JSON.stringify({ok:true,generatedRoutes:manifest.pages.length,outputDirectory:'dist',sitemapUrls:urls.length},null,2));
