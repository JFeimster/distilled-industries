#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const manifestPath = path.join(root, 'data', 'industries.pages.manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath,'utf8'));
const forbidden = [
  'guaranteed approval','guaranteed funding','no documentation required','instant approval for all applicants'
];
const providerRegistryPath = '/mnt/data/funding-providers.registry(1).json';
let providerNames = [];
try {
  const providers = JSON.parse(fs.readFileSync(providerRegistryPath,'utf8'));
  providerNames = (providers.entries || []).map(x => String(x.name || '').trim()).filter(Boolean);
} catch (_) {
  providerNames = ['Bank Breezy','David Allen Capital','8fig','Credibly','7 Figures Funding'];
}

const failures = [];
const seenRoutes = new Set();
const seenCanonicals = new Set();
let industryCount = 0, categoryCount = 0, homepageCount = 0;

function load(rel){
  const p = path.join(root, rel);
  if(!fs.existsSync(p)) { failures.push(`Missing source: ${rel}`); return null; }
  try { return JSON.parse(fs.readFileSync(p,'utf8')); }
  catch(e){ failures.push(`Invalid JSON: ${rel}: ${e.message}`); return null; }
}
function walkStrings(value, out=[]){
  if(typeof value === 'string') out.push(value);
  else if(Array.isArray(value)) value.forEach(v => walkStrings(v,out));
  else if(value && typeof value === 'object') Object.values(value).forEach(v => walkStrings(v,out));
  return out;
}

for (const entry of manifest.pages){
  if(seenRoutes.has(entry.route)) failures.push(`Duplicate route: ${entry.route}`);
  seenRoutes.add(entry.route);
  const doc = load(entry.source);
  if(!doc) continue;
  if(entry.type==='industry') industryCount++;
  if(entry.type==='category') categoryCount++;
  if(entry.type==='homepage') homepageCount++;

  if(doc.route !== entry.route) failures.push(`Route mismatch: ${entry.source}`);
  if(!doc.seo || !doc.seo.title || !doc.seo.description || !doc.seo.canonical) failures.push(`Missing SEO: ${entry.source}`);
  if(doc.seo?.canonical){
    if(seenCanonicals.has(doc.seo.canonical)) failures.push(`Duplicate canonical: ${doc.seo.canonical}`);
    seenCanonicals.add(doc.seo.canonical);
  }

  const strings = walkStrings(doc).join('\n').toLowerCase();
  forbidden.forEach(term => {
    if(strings.includes(term) && !(doc.compliance?.forbiddenClaims || []).map(x=>x.toLowerCase()).includes(term)){
      failures.push(`Forbidden public claim "${term}" found in ${entry.source}`);
    }
  });

  if(entry.type==='industry'){
    const required = ['id','slug','route','categoryId','categorySlug','categoryLabel','label','pageType','status','seo','hero','operatingReality','capitalUseCases','recommendedFundingPaths','qualificationSnapshot','faq','relatedIndustries','compliance','dataRefs'];
    required.forEach(k => { if(!(k in doc)) failures.push(`Missing ${k}: ${entry.source}`); });
    if((doc.capitalUseCases||[]).length < 3) failures.push(`Too few use cases: ${entry.source}`);
    if((doc.faq||[]).length < 3) failures.push(`Too few FAQs: ${entry.source}`);
    if((doc.relatedIndustries||[]).length < 2) failures.push(`Too few related industries: ${entry.source}`);
    providerNames.forEach(name => {
      if(!name || name.length <= 2) return;
      const rawStrings = walkStrings(doc).join('\n');
      const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp(`(^|[^A-Za-z0-9])${escaped}([^A-Za-z0-9]|$)`);
      if(re.test(rawStrings)) failures.push(`Provider leakage "${name}" in ${entry.source}`);
    });
  }
}

if(homepageCount!==1) failures.push(`Homepage count expected 1; got ${homepageCount}`);
if(categoryCount!==15) failures.push(`Category count expected 15; got ${categoryCount}`);
if(industryCount!==100) failures.push(`Industry count expected 100; got ${industryCount}`);
if(manifest.counts?.totalRoutes !== 116) failures.push(`Manifest route count expected 116; got ${manifest.counts?.totalRoutes}`);

if(failures.length){
  console.error(JSON.stringify({ok:false, failures}, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({
  ok:true,
  homepageCount,
  categoryCount,
  industryCount,
  totalRoutes:seenRoutes.size,
  uniqueCanonicals:seenCanonicals.size,
  providerLeakage:0,
  forbiddenClaimViolations:0
}, null, 2));
