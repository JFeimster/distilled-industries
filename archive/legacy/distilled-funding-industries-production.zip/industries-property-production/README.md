# Distilled Funding — Industries Property

**Production target:** `https://industries.distilledfunding.com`  
**Architecture:** JSON page contracts → deterministic static build → Vercel.

## What shipped

- 1 industries homepage
- 15 category pages
- 100 industry pages
- 116 canonical routes total
- JSON-LD: CollectionPage, WebPage, FAQPage, BreadcrumbList
- automatic navigation + related-industry linking
- sitemap.xml + robots.txt
- provider-leakage + forbidden-claim validator
- Variation 3 design system and static renderer

## Core files

- `data/industries-homepage.production.json`
- `data/industries.pages.manifest.json`
- `data/industries-pages.manifest.json` (compatibility alias)
- `data/industries.navigation.manifest.json`
- `data/industries-page.template.json`
- `data/industries.design-system.json`
- `CANONICAL-SITEMAP.txt`
- `BATCH-AUDIT.json`
- `validate-industries-pages.cjs`
- `validate-funding-pages.cjs` (compatibility wrapper)

## Local commands

```powershell
npm run validate
npm run build
```

No npm dependencies are required. The build is plain Node and writes the deployable site to `dist/`.

## Add an industry

1. Add the industry to `data/industries-seeds.registry.json`.
2. Generate a new page contract using `data/industries-page.template.json` as the contract.
3. Add the route to `data/industries.pages.manifest.json`.
4. Add navigation under the correct sector in `data/industries.navigation.manifest.json`.
5. Run `npm run validate`.
6. Run `npm run build`.
7. Deploy to Vercel.

## Conversion URL

Primary CTA: `https://www.distilledfunding.com/apply`

## Guardrails

Public pages intentionally suppress backend provider names and preserve the Moonshine Capital/Distilled Funding routing principle: understand the file first, then match the capital lane.
