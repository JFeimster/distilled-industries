#!/usr/bin/env node
require('./scripts/validate-industries-pages.cjs');
